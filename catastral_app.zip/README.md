# App Web de Lectura de Certificados Catastrales

Permite subir PDFs catastrales estándar y obtener automáticamente documentos notariales en Word.